Backend - Instrucciones

Modo desarrollo:
1. cd backend
2. npm install
3. npm run dev

Modo producción:
1. Configura variables de entorno (.env)
2. Usa un proceso como PM2 para correr: pm2 start index.js
