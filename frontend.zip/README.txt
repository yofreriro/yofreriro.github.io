Frontend - Instrucciones

Modo desarrollo:
1. cd frontend
2. npm install
3. npm run dev

Modo producción:
1. npm run build
2. Sirve la carpeta 'dist' con un servidor estático como nginx o serve
